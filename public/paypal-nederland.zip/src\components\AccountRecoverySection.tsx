'use client';

import React from 'react';
import { siteContent } from '@/data/content';
import {
  RefreshCw,
  Key,
  PhoneOff,
  ShieldBan,
  Activity,
  CheckCircle2,
  ArrowRight,
} from 'lucide-react';

const reasonIcons = [
  <Key key="key" className="w-5 h-5 text-[#0070BA]" />,
  <PhoneOff key="phone" className="w-5 h-5 text-amber-600" />,
  <ShieldBan key="ban" className="w-5 h-5 text-rose-600" />,
  <Activity key="activity" className="w-5 h-5 text-indigo-600" />,
];

export default function AccountRecoverySection() {
  const { accountRecovery } = siteContent;

  return (
    <section id={accountRecovery.id} className="py-16 md:py-24 bg-white scroll-mt-24 border-b border-slate-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mb-12">
          {/* Section badge */}
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-50 border border-blue-100 text-xs font-bold text-[#003087] uppercase tracking-wider mb-4">
            <RefreshCw className="w-3.5 h-3.5 text-[#0070BA]" />
            <span>Herstel & Toegang</span>
          </div>

          <h2 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-[#001C64] tracking-tight mb-3">
            {accountRecovery.heading}
          </h2>

          <h3 className="text-lg sm:text-xl font-bold text-[#003087] mb-3">
            {accountRecovery.subheading}
          </h3>

          <p className="text-base text-slate-700 leading-relaxed mb-2">
            {accountRecovery.intro}
          </p>

          <p className="text-sm font-semibold text-slate-900 uppercase tracking-wide">
            {accountRecovery.lead}
          </p>
        </div>

        {/* 4 Reasons Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-10">
          {accountRecovery.reasons.map((reason, index) => (
            <div
              key={index}
              className="p-6 rounded-2xl bg-[#F8FAFC] border border-slate-200/80 hover:border-blue-300 hover:bg-white hover:shadow-md transition-all duration-200 flex flex-col justify-between"
            >
              <div>
                <div className="p-3 rounded-xl bg-white border border-slate-200 inline-block mb-4 shadow-2xs">
                  {reasonIcons[index % reasonIcons.length]}
                </div>
                <h4 className="text-base font-bold text-slate-900 leading-snug">
                  {reason}
                </h4>
              </div>
              <div className="mt-4 pt-3 border-t border-slate-200/60 text-xs font-semibold text-[#0070BA]">
                Verificatie vereist
              </div>
            </div>
          ))}
        </div>

        {/* Closing Guidance */}
        <div className="p-6 sm:p-8 rounded-2xl bg-gradient-to-r from-blue-50 via-indigo-50/30 to-white border border-blue-200 shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
          <div className="flex items-start gap-4">
            <div className="p-3 rounded-xl bg-[#003087] text-white shrink-0 shadow-xs">
              <CheckCircle2 className="w-6 h-6" />
            </div>
            <p className="text-sm sm:text-base text-slate-800 leading-relaxed font-semibold">
              {accountRecovery.closing}
            </p>
          </div>
          <a
            href="#contact"
            className="shrink-0 inline-flex items-center gap-2 px-5 py-2.5 rounded-full text-sm font-semibold text-white bg-[#003087] hover:bg-[#001C64] transition-colors shadow-xs"
          >
            <span>Ondersteuning</span>
            <ArrowRight className="w-4 h-4" />
          </a>
        </div>
      </div>
    </section>
  );
}
