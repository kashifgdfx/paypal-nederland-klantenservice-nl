'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { navigationLinks } from '@/data/content';
import { Menu, X, ShieldCheck, ChevronRight, Globe } from 'lucide-react';

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [scrollProgress, setScrollProgress] = useState(0);

  useEffect(() => {
    const handleScroll = () => {
      const totalScroll = document.documentElement.scrollHeight - window.innerHeight;
      const currentScroll = window.scrollY;
      setScrolled(currentScroll > 20);
      if (totalScroll > 0) {
        setScrollProgress((currentScroll / totalScroll) * 100);
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header className={`sticky top-0 z-50 transition-all duration-300 ${scrolled ? 'bg-white/95 backdrop-blur-md shadow-xs border-b border-slate-200/80' : 'bg-white border-b border-slate-100'}`}>
      {/* Scroll indicator bar */}
      <div
        className="h-1 bg-gradient-to-r from-[#003087] via-[#0070BA] to-[#00CFDE] transition-all duration-150"
        style={{ width: `${scrollProgress}%` }}
        role="progressbar"
        aria-valuenow={Math.round(scrollProgress)}
        aria-valuemin={0}
        aria-valuemax={100}
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Logo / Brand */}
          <Link href="#" className="flex items-center gap-3 group focus:outline-hidden">
            <div className="flex items-center">
              {/* PayPal Double-P stylized monogram */}
              <svg className="w-9 h-10 transition-transform group-hover:scale-105 duration-200" viewBox="0 0 34 40" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M26.2424 9.17627C25.4222 3.65584 21.0558 0 14.8028 0H3.3421C2.33967 0 1.48834 0.709971 1.34149 1.70588L0.00787595 10.7423L0.00512695 10.7607L0.00787595 10.7818C-0.0388421 11.1066 0.0326081 11.4342 0.207869 11.7061C0.383131 11.978 0.650893 12.1769 0.963286 12.2676L0.981608 12.2704L4.85651 12.2704L6.37894 22.5694L6.32123 22.9597C6.18379 23.8897 6.9038 24.7171 7.84277 24.7171H12.9814C13.8829 24.7171 14.6481 24.0795 14.7791 23.1896L14.7928 23.0962L16.2797 13.6749L16.3274 13.3725C16.4584 12.4826 17.2235 11.845 18.125 11.845H19.5768C23.9575 11.845 27.0427 10.0673 26.2424 9.17627Z" fill="#003087"/>
                <path d="M29.5855 12.5654C28.7653 7.045 24.3989 3.38916 18.1459 3.38916H6.68519C5.68276 3.38916 4.83143 4.09913 4.68458 5.09504L0.0078125 36.7865C-0.126868 37.6974 0.579459 38.5137 1.50027 38.5137H8.38466C9.28616 38.5137 10.0513 37.8761 10.1823 36.9862L10.196 36.8928L12.0006 25.4527L12.0482 25.1503C12.1792 24.2604 12.9444 23.6228 13.8459 23.6228H16.3458C22.6865 23.6228 27.6534 21.054 29.0886 13.5878L29.5855 12.5654Z" fill="#0070BA" fillOpacity="0.85"/>
                <path d="M26.2424 9.17627C25.4222 3.65584 21.0558 0 14.8028 0H3.3421C2.33967 0 1.48834 0.709971 1.34149 1.70588L0.00787595 10.7423C-0.0550477 11.1685 0.0814666 11.6033 0.380482 11.9287C0.679498 12.2541 1.11181 12.4384 1.56075 12.4323H7.07008L8.71887 23.585C8.85262 24.4925 9.62779 25.1767 10.5444 25.1767H15.1772C21.518 25.1767 26.4849 22.6079 27.92 15.1417L26.2424 9.17627Z" fill="#001C64"/>
              </svg>
              <span className="ml-2 text-2xl font-black tracking-tight text-[#003087]">
                PayPal
              </span>
            </div>
            <div className="h-6 w-px bg-slate-300 hidden sm:block" />
            <div className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-slate-100 text-xs font-semibold text-slate-700">
              <ShieldCheck className="w-3.5 h-3.5 text-[#0070BA]" />
              <span>Klantenservice NL</span>
            </div>
          </Link>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center gap-1 xl:gap-2">
            {navigationLinks.slice(0, 5).map((link) => (
              <a
                key={link.id}
                href={`#${link.id}`}
                className="px-3 py-2 text-sm font-medium text-slate-700 hover:text-[#003087] hover:bg-slate-50 rounded-lg transition-colors"
              >
                {link.shortTitle.replace('PayPal ', '')}
              </a>
            ))}
            <a
              href="#contact"
              className="px-3 py-2 text-sm font-medium text-slate-700 hover:text-[#003087] hover:bg-slate-50 rounded-lg transition-colors"
            >
              Contact
            </a>
            <a
              href="#faq"
              className="px-3 py-2 text-sm font-medium text-slate-700 hover:text-[#003087] hover:bg-slate-50 rounded-lg transition-colors"
            >
              FAQ
            </a>
          </nav>

          {/* Right Action & Locale */}
          <div className="hidden sm:flex items-center gap-3">
            <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-600 px-2.5 py-1.5 rounded-full border border-slate-200 bg-slate-50">
              <Globe className="w-3.5 h-3.5 text-slate-500" />
              <span>NL</span>
            </div>

            <a
              href="#contact"
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full text-sm font-semibold text-white bg-[#003087] hover:bg-[#001C64] shadow-sm hover:shadow-md transition-all duration-200"
            >
              <span>Klantenservice</span>
              <ChevronRight className="w-4 h-4" />
            </a>
          </div>

          {/* Mobile Menu Button */}
          <div className="flex lg:hidden items-center gap-2">
            <a
              href="#contact"
              className="sm:hidden text-xs font-semibold px-3 py-1.5 rounded-full text-white bg-[#003087]"
            >
              Contact
            </a>
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="p-2 rounded-xl text-slate-700 hover:bg-slate-100 focus:outline-hidden"
              aria-label="Menu openen"
              aria-expanded={isOpen}
            >
              {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {isOpen && (
        <div className="lg:hidden bg-white border-b border-slate-200 px-4 pt-3 pb-6 shadow-xl animate-in slide-in-from-top duration-200">
          <div className="flex flex-col gap-1">
            {navigationLinks.map((link) => (
              <a
                key={link.id}
                href={`#${link.id}`}
                onClick={() => setIsOpen(false)}
                className="px-3 py-2.5 rounded-lg text-base font-medium text-slate-800 hover:bg-slate-50 hover:text-[#003087] flex items-center justify-between"
              >
                <span>{link.title}</span>
                <ChevronRight className="w-4 h-4 text-slate-400" />
              </a>
            ))}
          </div>

          <div className="mt-4 pt-4 border-t border-slate-100 flex items-center justify-between">
            <div className="flex items-center gap-2 text-sm text-slate-600">
              <Globe className="w-4 h-4 text-[#0070BA]" />
              <span className="font-medium">Nederland (Nederlands)</span>
            </div>
            <a
              href="#contact"
              onClick={() => setIsOpen(false)}
              className="px-4 py-2 rounded-full text-sm font-semibold text-white bg-[#003087]"
            >
              Direct Hulp
            </a>
          </div>
        </div>
      )}
    </header>
  );
}
