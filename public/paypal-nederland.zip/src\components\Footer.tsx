'use client';

import React from 'react';
import { siteContent, navigationLinks } from '@/data/content';
import { ShieldCheck, Globe, Lock, ArrowUp } from 'lucide-react';

export default function Footer() {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-white border-t border-slate-200 text-slate-600">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-16 pb-12">
        {/* Brand & Meta description summary */}
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-10 mb-12">
          <div className="lg:col-span-2">
            <div className="flex items-center gap-3 mb-4">
              {/* PayPal Double-P logo */}
              <svg className="w-8 h-9" viewBox="0 0 34 40" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M26.2424 9.17627C25.4222 3.65584 21.0558 0 14.8028 0H3.3421C2.33967 0 1.48834 0.709971 1.34149 1.70588L0.00787595 10.7423L0.00512695 10.7607L0.00787595 10.7818C-0.0388421 11.1066 0.0326081 11.4342 0.207869 11.7061C0.383131 11.978 0.650893 12.1769 0.963286 12.2676L0.981608 12.2704L4.85651 12.2704L6.37894 22.5694L6.32123 22.9597C6.18379 23.8897 6.9038 24.7171 7.84277 24.7171H12.9814C13.8829 24.7171 14.6481 24.0795 14.7791 23.1896L14.7928 23.0962L16.2797 13.6749L16.3274 13.3725C16.4584 12.4826 17.2235 11.845 18.125 11.845H19.5768C23.9575 11.845 27.0427 10.0673 26.2424 9.17627Z" fill="#003087"/>
                <path d="M29.5855 12.5654C28.7653 7.045 24.3989 3.38916 18.1459 3.38916H6.68519C5.68276 3.38916 4.83143 4.09913 4.68458 5.09504L0.0078125 36.7865C-0.126868 37.6974 0.579459 38.5137 1.50027 38.5137H8.38466C9.28616 38.5137 10.0513 37.8761 10.1823 36.9862L10.196 36.8928L12.0006 25.4527L12.0482 25.1503C12.1792 24.2604 12.9444 23.6228 13.8459 23.6228H16.3458C22.6865 23.6228 27.6534 21.054 29.0886 13.5878L29.5855 12.5654Z" fill="#0070BA" fillOpacity="0.85"/>
                <path d="M26.2424 9.17627C25.4222 3.65584 21.0558 0 14.8028 0H3.3421C2.33967 0 1.48834 0.709971 1.34149 1.70588L0.00787595 10.7423C-0.0550477 11.1685 0.0814666 11.6033 0.380482 11.9287C0.679498 12.2541 1.11181 12.4384 1.56075 12.4323H7.07008L8.71887 23.585C8.85262 24.4925 9.62779 25.1767 10.5444 25.1767H15.1772C21.518 25.1767 26.4849 22.6079 27.92 15.1417L26.2424 9.17627Z" fill="#001C64"/>
              </svg>
              <span className="text-xl font-black text-[#003087]">
                PayPal Nederland
              </span>
            </div>

            <p className="text-sm text-slate-700 leading-relaxed max-w-lg mb-4">
              {siteContent.metadata.description}
            </p>

            <div className="flex items-center gap-3 text-xs text-slate-500">
              <span className="inline-flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5 text-[#0070BA]" />
                Veilige verbinding
              </span>
              <span>•</span>
              <span className="inline-flex items-center gap-1">
                <Lock className="w-3.5 h-3.5 text-[#003087]" />
                Officiële richtlijnen
              </span>
            </div>
          </div>

          {/* Quick link columns */}
          <div>
            <h4 className="text-xs uppercase tracking-wider font-bold text-slate-900 mb-3">
              Account & Beveiliging
            </h4>
            <ul className="space-y-2 text-sm">
              <li>
                <a href="#login-problemen" className="hover:text-[#003087] transition-colors">
                  {siteContent.loginProblems.heading}
                </a>
              </li>
              <li>
                <a href="#wachtwoord-wijzigen" className="hover:text-[#003087] transition-colors">
                  {siteContent.passwordChange.heading}
                </a>
              </li>
              <li>
                <a href="#account-herstellen" className="hover:text-[#003087] transition-colors">
                  {siteContent.accountRecovery.heading}
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="text-xs uppercase tracking-wider font-bold text-slate-900 mb-3">
              Betalingen & Ondersteuning
            </h4>
            <ul className="space-y-2 text-sm">
              <li>
                <a href="#betalingsproblemen" className="hover:text-[#003087] transition-colors">
                  {siteContent.paymentProblems.heading}
                </a>
              </li>
              <li>
                <a href="#opwaarderen" className="hover:text-[#003087] transition-colors">
                  {siteContent.balance.heading}
                </a>
              </li>
              <li>
                <a href="#contact" className="hover:text-[#003087] transition-colors">
                  {siteContent.contact.heading}
                </a>
              </li>
              <li>
                <a href="#refund-en-klachten" className="hover:text-[#003087] transition-colors">
                  {siteContent.refund.heading}
                </a>
              </li>
              <li>
                <a href="#telefoonnummer" className="hover:text-[#003087] transition-colors">
                  {siteContent.phoneNumber.heading}
                </a>
              </li>
              <li>
                <a href="#faq" className="hover:text-[#003087] transition-colors">
                  {siteContent.faqs.heading}
                </a>
              </li>
            </ul>
          </div>
        </div>

        {/* Verbatim Disclaimer & Trust Note */}
        <div className="pt-8 border-t border-slate-200/80 mb-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs text-slate-500 leading-relaxed">
            <p>
              {siteContent.hero.intro2}
            </p>
            <p>
              {siteContent.contact.closing}
            </p>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="pt-6 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <div className="flex items-center gap-2">
            <Globe className="w-3.5 h-3.5 text-[#0070BA]" />
            <span className="font-semibold text-slate-700">Nederland · Nederlands</span>
            <span className="text-slate-300">|</span>
            <span className="font-mono text-[11px] text-slate-400">/{siteContent.metadata.url}</span>
          </div>

          <button
            onClick={scrollToTop}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold transition-colors"
          >
            <span>Naar boven</span>
            <ArrowUp className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </footer>
  );
}
