'use client';

import React, { useEffect, useRef } from 'react';
import { siteContent, navigationLinks } from '@/data/content';
import {
  ShieldCheck,
  Lock,
  ArrowRight,
  HelpCircle,
  KeyRound,
  RefreshCw,
  CreditCard,
  PhoneCall,
  RotateCcw,
  Wallet,
} from 'lucide-react';
import gsap from 'gsap';

const topicIcons: Record<string, React.ReactNode> = {
  'login-problemen': <Lock className="w-4 h-4 text-[#0070BA]" />,
  'wachtwoord-wijzigen': <KeyRound className="w-4 h-4 text-[#0070BA]" />,
  'account-herstellen': <RefreshCw className="w-4 h-4 text-[#0070BA]" />,
  'betalingsproblemen': <CreditCard className="w-4 h-4 text-[#0070BA]" />,
  'opwaarderen': <Wallet className="w-4 h-4 text-[#0070BA]" />,
  'contact': <HelpCircle className="w-4 h-4 text-[#0070BA]" />,
  'refund-en-klachten': <RotateCcw className="w-4 h-4 text-[#0070BA]" />,
  'telefoonnummer': <PhoneCall className="w-4 h-4 text-[#0070BA]" />,
  'faq': <HelpCircle className="w-4 h-4 text-[#0070BA]" />,
};

export default function HeroSection() {
  const { hero } = siteContent;
  const heroRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.from('.gsap-hero-badge', {
        opacity: 0,
        y: -15,
        duration: 0.6,
        ease: 'power3.out',
      });
      gsap.from('.gsap-hero-title', {
        opacity: 0,
        y: 25,
        duration: 0.8,
        delay: 0.15,
        ease: 'power3.out',
      });
      gsap.from('.gsap-hero-desc', {
        opacity: 0,
        y: 20,
        duration: 0.8,
        delay: 0.3,
        ease: 'power3.out',
      });
      gsap.from('.gsap-hero-card', {
        opacity: 0,
        scale: 0.96,
        duration: 0.8,
        delay: 0.45,
        ease: 'power3.out',
      });
      gsap.from('.gsap-nav-chip', {
        opacity: 0,
        y: 15,
        stagger: 0.04,
        duration: 0.5,
        delay: 0.6,
        ease: 'power2.out',
      });
    }, heroRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={heroRef}
      className="relative overflow-hidden bg-gradient-to-b from-[#F0F7FF] via-[#F8FAFC] to-white pt-12 pb-20 md:pt-16 md:pb-28 border-b border-slate-100"
    >
      {/* Ambient fintech light effects */}
      <div className="absolute top-0 right-1/4 w-96 h-96 bg-blue-100/60 rounded-full blur-3xl pointer-events-none -z-10" />
      <div className="absolute bottom-0 left-1/3 w-80 h-80 bg-cyan-100/40 rounded-full blur-3xl pointer-events-none -z-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          {/* Trust badge */}
          <div className="gsap-hero-badge inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white border border-blue-200/80 shadow-xs mb-8">
            <ShieldCheck className="w-4 h-4 text-[#0070BA]" />
            <span className="text-xs sm:text-sm font-semibold text-[#003087]">
              Officiële Klantenservice Informatie Nederland
            </span>
          </div>

          {/* Exact Verbatim H1 */}
          <h1 className="gsap-hero-title text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-black tracking-tight text-[#001C64] leading-[1.15] mb-6">
            {hero.h1}
          </h1>

          {/* Exact Verbatim Intro Paragraph 1 */}
          <p className="gsap-hero-desc text-base sm:text-lg md:text-xl text-slate-700 font-normal leading-relaxed mb-6">
            {hero.intro1}
          </p>

          {/* Exact Verbatim Intro Paragraph 2 */}
          <div className="gsap-hero-card p-5 sm:p-6 rounded-2xl bg-white border border-slate-200/80 shadow-sm text-left mb-10">
            <div className="flex items-start gap-3">
              <div className="p-2 rounded-xl bg-blue-50 text-[#003087] shrink-0 mt-0.5">
                <Lock className="w-5 h-5 text-[#0070BA]" />
              </div>
              <p className="text-sm sm:text-base text-slate-700 leading-relaxed font-normal">
                {hero.intro2}
              </p>
            </div>
          </div>

          {/* Quick jumps navigation grid */}
          <div className="mt-8 text-left">
            <h2 className="text-xs uppercase tracking-wider font-bold text-slate-500 mb-4 text-center">
              Snelle navigatie naar oplossingen
            </h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2.5 sm:gap-3">
              {navigationLinks.map((item) => (
                <a
                  key={item.id}
                  href={`#${item.id}`}
                  className="gsap-nav-chip group flex items-center justify-between p-3 sm:p-3.5 rounded-xl bg-white hover:bg-blue-50/70 border border-slate-200 hover:border-blue-300 shadow-2xs hover:shadow-xs transition-all duration-150"
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <span className="p-1.5 rounded-lg bg-slate-50 group-hover:bg-white text-[#0070BA] shrink-0 border border-slate-100">
                      {topicIcons[item.id] || <HelpCircle className="w-4 h-4 text-[#0070BA]" />}
                    </span>
                    <span className="text-xs sm:text-sm font-semibold text-slate-800 group-hover:text-[#003087] truncate">
                      {item.title}
                    </span>
                  </div>
                  <ArrowRight className="w-3.5 h-3.5 text-slate-400 group-hover:text-[#003087] group-hover:translate-x-0.5 transition-all shrink-0 ml-1" />
                </a>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
