'use client';

import React from 'react';
import { siteContent } from '@/data/content';
import {
  KeyRound,
  ShieldCheck,
  UserCheck,
  Settings,
  Shield,
  Key,
  CheckCircle,
  AlertTriangle,
} from 'lucide-react';

const stepIcons = [
  <UserCheck key="1" className="w-5 h-5 text-white" />,
  <Settings key="2" className="w-5 h-5 text-white" />,
  <Shield key="3" className="w-5 h-5 text-white" />,
  <Key key="4" className="w-5 h-5 text-white" />,
  <CheckCircle key="5" className="w-5 h-5 text-white" />,
];

export default function PasswordChangeSection() {
  const { passwordChange } = siteContent;

  return (
    <section id={passwordChange.id} className="py-16 md:py-24 bg-[#F8FAFC] scroll-mt-24 border-b border-slate-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mb-12">
          {/* Section badge */}
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-50 border border-blue-100 text-xs font-bold text-[#003087] uppercase tracking-wider mb-4">
            <KeyRound className="w-3.5 h-3.5 text-[#0070BA]" />
            <span>Accountbeveiliging</span>
          </div>

          <h2 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-[#001C64] tracking-tight mb-3">
            {passwordChange.heading}
          </h2>

          <h3 className="text-lg sm:text-xl font-bold text-[#003087] mb-3">
            {passwordChange.subheading}
          </h3>

          <p className="text-base text-slate-700 leading-relaxed mb-2">
            {passwordChange.intro}
          </p>

          <p className="text-sm font-semibold text-slate-900 uppercase tracking-wide">
            {passwordChange.lead}
          </p>
        </div>

        {/* 5-Step Process Timeline Cards */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-10">
          {passwordChange.steps.map((step, index) => (
            <div
              key={index}
              className="relative p-5 rounded-2xl bg-white border border-slate-200/90 shadow-2xs hover:shadow-md hover:border-blue-300 transition-all duration-200 flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-4">
                  <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-[#003087] to-[#0070BA] flex items-center justify-center shadow-xs">
                    {stepIcons[index]}
                  </div>
                  <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-blue-50 text-[#003087]">
                    Stap {index + 1}
                  </span>
                </div>
                <p className="text-sm sm:text-base font-bold text-slate-900 leading-snug">
                  {step}
                </p>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-100 flex items-center gap-1.5 text-xs text-slate-500 font-medium">
                <CheckCircle className="w-3.5 h-3.5 text-emerald-600" />
                <span>Geverifieerde stap</span>
              </div>
            </div>
          ))}
        </div>

        {/* Verbatim Security Advisory */}
        <div className="p-6 rounded-2xl bg-amber-50 border border-amber-200 shadow-2xs flex items-start gap-4">
          <div className="p-2.5 rounded-xl bg-amber-100 text-amber-800 shrink-0">
            <AlertTriangle className="w-5 h-5" />
          </div>
          <div>
            <span className="text-xs font-bold text-amber-900 uppercase tracking-wider block mb-0.5">
              Belangrijke beveiligingsregel
            </span>
            <p className="text-sm sm:text-base text-amber-950 font-semibold leading-relaxed">
              {passwordChange.closing}
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
