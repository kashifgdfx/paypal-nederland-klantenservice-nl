'use client';

import React from 'react';
import { siteContent } from '@/data/content';
import { ShieldCheck, HelpCircle, ArrowRight, ExternalLink } from 'lucide-react';

export default function CTASection() {
  const { contact } = siteContent;

  return (
    <section className="py-16 md:py-24 bg-gradient-to-br from-[#001C64] via-[#003087] to-[#0070BA] text-white relative overflow-hidden">
      {/* Background decorations */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-white/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-[#00CFDE]/10 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="max-w-4xl mx-auto text-center">
          {/* Trust badge */}
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/10 backdrop-blur-md border border-white/20 text-xs sm:text-sm font-semibold text-white mb-6">
            <ShieldCheck className="w-4 h-4 text-[#00CFDE]" />
            <span>{contact.heading}</span>
          </div>

          <h2 className="text-3xl sm:text-4xl md:text-5xl font-black tracking-tight text-white mb-6">
            {contact.subheading}
          </h2>

          <p className="text-base sm:text-lg md:text-xl text-blue-100 font-normal leading-relaxed mb-8 max-w-3xl mx-auto">
            {contact.intro}
          </p>

          <div className="p-5 sm:p-6 rounded-2xl bg-white/10 backdrop-blur-md border border-white/20 text-center max-w-2xl mx-auto mb-10">
            <p className="text-sm sm:text-base font-semibold text-white">
              {contact.closing}
            </p>
          </div>

          {/* Action buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <a
              href="#contact"
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-8 py-4 rounded-full text-base font-bold text-[#001C64] bg-white hover:bg-slate-100 shadow-lg hover:shadow-xl transition-all duration-200"
            >
              <span>{contact.heading}</span>
              <ArrowRight className="w-5 h-5" />
            </a>

            <a
              href="#faq"
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-8 py-4 rounded-full text-base font-semibold text-white bg-white/10 hover:bg-white/20 border border-white/30 backdrop-blur-xs transition-all duration-200"
            >
              <span>Veelgestelde Vragen</span>
              <ExternalLink className="w-4 h-4" />
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
