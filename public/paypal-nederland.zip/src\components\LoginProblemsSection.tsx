'use client';

import React from 'react';
import { siteContent } from '@/data/content';
import {
  Lock,
  KeyRound,
  AlertCircle,
  ShieldAlert,
  Smartphone,
  CheckCircle2,
  ArrowRight,
} from 'lucide-react';

const causeIcons = [
  <KeyRound key="key" className="w-5 h-5 text-[#0070BA]" />,
  <AlertCircle key="alert" className="w-5 h-5 text-amber-600" />,
  <ShieldAlert key="shield" className="w-5 h-5 text-[#003087]" />,
  <Lock key="lock" className="w-5 h-5 text-rose-600" />,
  <Smartphone key="phone" className="w-5 h-5 text-indigo-600" />,
];

export default function LoginProblemsSection() {
  const { loginProblems } = siteContent;

  return (
    <section id={loginProblems.id} className="py-16 md:py-24 bg-white scroll-mt-24 border-b border-slate-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mb-12">
          {/* Section badge */}
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-50 border border-blue-100 text-xs font-bold text-[#003087] uppercase tracking-wider mb-4">
            <Lock className="w-3.5 h-3.5 text-[#0070BA]" />
            <span>Inloggen & Beveiliging</span>
          </div>

          <h2 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-[#001C64] tracking-tight mb-3">
            {loginProblems.heading}
          </h2>

          <h3 className="text-lg sm:text-xl font-bold text-[#003087] mb-4">
            {loginProblems.subheading}
          </h3>

          <p className="text-base text-slate-700">
            {loginProblems.lead}
          </p>
        </div>

        {/* Diagnostic Grid of Causes */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-10">
          {loginProblems.causes.map((cause, index) => (
            <div
              key={index}
              className="p-5 rounded-2xl bg-[#F8FAFC] border border-slate-200/80 hover:border-blue-300 hover:bg-white hover:shadow-md transition-all duration-200 flex items-start gap-4"
            >
              <div className="p-2.5 rounded-xl bg-white border border-slate-200 shrink-0 shadow-2xs">
                {causeIcons[index % causeIcons.length]}
              </div>
              <div>
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1">
                  Oorzaak {index + 1}
                </span>
                <h4 className="text-base font-bold text-slate-900">
                  {cause}
                </h4>
              </div>
            </div>
          ))}
        </div>

        {/* Verbatim Advice Box */}
        <div className="p-6 sm:p-8 rounded-2xl bg-gradient-to-br from-[#F0F7FF] to-white border border-blue-200/90 shadow-sm">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
            <div className="flex items-start gap-4">
              <div className="p-3 rounded-xl bg-[#003087] text-white shrink-0 shadow-xs">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <p className="text-sm sm:text-base text-slate-800 leading-relaxed font-medium">
                {loginProblems.closing}
              </p>
            </div>
            <div className="shrink-0 flex items-center gap-3">
              <a
                href="#wachtwoord-wijzigen"
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full text-sm font-semibold text-white bg-[#0070BA] hover:bg-[#003087] shadow-xs transition-colors"
              >
                <span>Wachtwoord opties</span>
                <ArrowRight className="w-4 h-4" />
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
